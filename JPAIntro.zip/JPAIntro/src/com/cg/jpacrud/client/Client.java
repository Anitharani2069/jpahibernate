package com.cg.jpacrud.client;

import java.util.Scanner;
import com.cg.jpacrud.entities.Author;
import com.cg.jpacrud.service.AuthorService;
import com.cg.jpacrud.service.AuthorServiceImpl;

public class Client {

	public static void main(String[] args) {

		//Debug this program as Debug -> Debug as Java Application
		
		AuthorService service = new AuthorServiceImpl();
		Author author = new Author();
		for(;;)
		{
			Scanner sc=new Scanner(System.in);
			
			System.out.println("1. Insert");
			System.out.println("2. Update");
			System.out.println("3. Delete");
			System.out.println("4. Find");
			System.out.println("5. Exit");

			System.out.println("Enter your choice:");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:
			
			//For inserting records
					author.setAuthorID(11);
					author.setFirstName("Supriya");
					author.setLastName("Gondhali");
					author.setMiddleName("Shital");
					author.setPhoneNo(94562);
					
					service.addAuthor(author);
					System.out.println("added\n"  + author.getFirstName() );
					//bs.createAccount();
					break;
			case 2:	author.setFirstName("Snehal");
					author.setLastName("Chougule");
					author.setMiddleName("rajendra");
					service.updateAuthor(author);
					
					System.out.println("updated");
					break;
			case 3:	service.removeAuthor(author);
					System.out.println("End of program...");
					break;
			case 4:	author = service.findAuthorById(11);
					System.out.print("ID:"+author.getAuthorID());
					System.out.println(" Name:"+author.getFirstName());
					
					break;
			
			case 5: System.exit(0);
					break;
				
		}
		System.out.println("do you want to continue");
			String str=sc.next();
			if(str.equals("y")||str.equals("Y"))
			{
				continue;
			}
			else
			{
				break;
			}
		}

	}

}







